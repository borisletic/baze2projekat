package rs.ac.uns.ftn.db.jdbc.alumniclub.dao;

import rs.ac.uns.ftn.db.jdbc.alumniclub.dto.EventDTO;

import java.util.List;

public interface TransactionDAO {
    boolean createCompleteEvent(EventDTO event, int universityId, int eventTypeId, List<String> sessionDescriptions);
    boolean deleteCompleteEvent(int eventId);
    boolean registerAlumnusForEventWithAward(int alumnusId, int eventId, String awardName);
}