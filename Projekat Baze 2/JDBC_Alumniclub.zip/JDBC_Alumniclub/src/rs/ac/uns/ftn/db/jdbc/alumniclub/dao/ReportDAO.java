package rs.ac.uns.ftn.db.jdbc.alumniclub.dao;

import java.util.List;
import java.util.Map;

public interface ReportDAO {
    // Jednostavan upit - broj alumnista po odseku
    List<Map<String, Object>> getAlumniCountByDepartment();

    // Kompleksan upit - detaljni izvještaj o događajima
    List<Map<String, Object>> getDetailedEventReport();

    // Kompleksan upit - analiza aktivnosti po lokacijama
    List<Map<String, Object>> getActivityAnalysisByLocation();

    // Kompleksan upit - hijerarhijska analiza koordinatora
    List<Map<String, Object>> getCoordinatorHierarchyAnalysis();

    // Izvještaj o najaktivnijim alumnistima
    List<Map<String, Object>> getMostActiveAlumniReport();

    // Efikasnost donatora
    List<Map<String, Object>> getDonorEfficiencyReport();

    // Mesečni izvještaj aktivnosti
    List<Map<String, Object>> getMonthlyActivityReport();
}
