package rs.ac.uns.ftn.db.jdbc.alumniclub.dao;

import rs.ac.uns.ftn.db.jdbc.alumniclub.dto.AlumnusDTO;

import java.util.List;

public interface AlumnusDAO {
    List<AlumnusDTO> findAll();
    AlumnusDTO findById(int id);
    boolean insert(AlumnusDTO alumnus);
    boolean update(AlumnusDTO alumnus);
    boolean delete(int id);
    List<AlumnusDTO> findAlumniByDepartment(int departmentId);
    List<AlumnusDTO> findAlumniByEvent(int eventId);
}