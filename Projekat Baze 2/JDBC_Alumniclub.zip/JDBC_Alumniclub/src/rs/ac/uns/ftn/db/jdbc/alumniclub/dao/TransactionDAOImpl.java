package rs.ac.uns.ftn.db.jdbc.alumniclub.dao;

import rs.ac.uns.ftn.db.jdbc.alumniclub.connection.DatabaseConnection;
import rs.ac.uns.ftn.db.jdbc.alumniclub.dto.EventDTO;

import java.sql.*;
import java.util.List;

public class TransactionDAOImpl implements TransactionDAO {
    private Connection connection;

    // Fixed no-arg constructor - gets connection from DatabaseConnection
    public TransactionDAOImpl() {
        try {
            this.connection = DatabaseConnection.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to establish database connection", e);
        }
    }

    // Add constructor that accepts connection for flexibility
    public TransactionDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public boolean createCompleteEvent(EventDTO event, int universityId, int eventTypeId, List<String> sessionDescriptions) {
        try {
            connection.setAutoCommit(false);

            // 1. Dodavanje događaja
            String insertEventSql = "INSERT INTO DOGAĐAJ (idD, NazD, OpisD, DatD) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = connection.prepareStatement(insertEventSql)) {
                ps.setInt(1, event.getIdD());
                ps.setString(2, event.getNazD());
                ps.setString(3, event.getOpisD());
                ps.setString(4, event.getDatD());
                ps.executeUpdate();
            }

            // 2. Povezivanje sa univerzitetom
            String linkUniversitySql = "INSERT INTO ORGANIZUJE (idU, idD) VALUES (?, ?)";
            try (PreparedStatement ps = connection.prepareStatement(linkUniversitySql)) {
                ps.setInt(1, universityId);
                ps.setInt(2, event.getIdD());
                ps.executeUpdate();
            }

            // 3. Dodela tipa događaja
            String linkEventTypeSql = "INSERT INTO PRIPADA (idD, idTd) VALUES (?, ?)";
            try (PreparedStatement ps = connection.prepareStatement(linkEventTypeSql)) {
                ps.setInt(1, event.getIdD());
                ps.setInt(2, eventTypeId);
                ps.executeUpdate();
            }

            // 4. Kreiranje sesija
            String insertSessionSql = "INSERT INTO SESIJA (idS, OpisS, idD) VALUES (?, ?, ?)";
            try (PreparedStatement ps = connection.prepareStatement(insertSessionSql)) {
                for (int i = 0; i < sessionDescriptions.size(); i++) {
                    ps.setInt(1, event.getIdD() * 10 + i + 1);
                    ps.setString(2, sessionDescriptions.get(i));
                    ps.setInt(3, event.getIdD());
                    ps.executeUpdate();
                }
            }

            // 5. Dodavanje osnovnih aktivnosti za svaku sesiju
            String insertActivitySql = "INSERT INTO AKTIVNOST (rbrA, idS, opisA, idL) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = connection.prepareStatement(insertActivitySql)) {
                for (int i = 0; i < sessionDescriptions.size(); i++) {
                    int sessionId = event.getIdD() * 10 + i + 1;
                    ps.setInt(1, 1);
                    ps.setInt(2, sessionId);
                    ps.setString(3, "Osnovna aktivnost za " + sessionDescriptions.get(i));
                    ps.setInt(4, 1); // Default lokacija
                    ps.executeUpdate();
                }
            }

            // 6. Kreiranje osnovnog priznanja
            String insertAwardSql = "INSERT INTO PRIZNANJE (idP, NazP, idD) VALUES (?, ?, ?)";
            try (PreparedStatement ps = connection.prepareStatement(insertAwardSql)) {
                ps.setInt(1, event.getIdD() * 100);
                ps.setString(2, "Priznanje za " + event.getNazD());
                ps.setInt(3, event.getIdD());
                ps.executeUpdate();
            }

            // 7. Dodavanje kao pojedinačno priznanje
            String insertIndividualAwardSql = "INSERT INTO POJEDINAČNO_PRIZNANJE (idP) VALUES (?)";
            try (PreparedStatement ps = connection.prepareStatement(insertIndividualAwardSql)) {
                ps.setInt(1, event.getIdD() * 100);
                ps.executeUpdate();
            }

            connection.commit();
            return true;

        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Greška pri rollback-u: " + rollbackEx.getMessage());
            }
            System.err.println("Greška pri kreiranju događaja: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                System.err.println("Greška pri vraćanju autoCommit: " + e.getMessage());
            }
        }
    }

    @Override
    public boolean deleteCompleteEvent(int eventId) {
        try {
            connection.setAutoCommit(false);

            // 1. Brisanje koordinacije aktivnosti
            String deleteCoordinationSql = """
                DELETE ko FROM KOORDINIRA ko
                JOIN AKTIVNOST a ON ko.rbrA = a.rbrA AND ko.idS = a.idS
                JOIN SESIJA s ON a.idS = s.idS
                WHERE s.idD = ?
            """;
            try (PreparedStatement ps = connection.prepareStatement(deleteCoordinationSql)) {
                ps.setInt(1, eventId);
                ps.executeUpdate();
            }

            // 2. Brisanje aktivnosti
            String deleteActivitiesSql = """
                DELETE a FROM AKTIVNOST a
                JOIN SESIJA s ON a.idS = s.idS
                WHERE s.idD = ?
            """;
            try (PreparedStatement ps = connection.prepareStatement(deleteActivitiesSql)) {
                ps.setInt(1, eventId);
                ps.executeUpdate();
            }

            // 3. Brisanje sesija
            String deleteSessionsSql = "DELETE FROM SESIJA WHERE idD = ?";
            try (PreparedStatement ps = connection.prepareStatement(deleteSessionsSql)) {
                ps.setInt(1, eventId);
                ps.executeUpdate();
            }

            // 4. Brisanje dodeljenih priznanja
            String deleteAwardAssignmentsSql = """
                DELETE FROM DOBIJA_PRIZNANJE 
                WHERE idP IN (SELECT idP FROM PRIZNANJE WHERE idD = ?)
            """;
            try (PreparedStatement ps = connection.prepareStatement(deleteAwardAssignmentsSql)) {
                ps.setInt(1, eventId);
                ps.executeUpdate();
            }

            // 5. Brisanje tipova priznanja
            String deleteGroupAwardsSql = """
                DELETE FROM GRUPNO_PRIZNANJE 
                WHERE idP IN (SELECT idP FROM PRIZNANJE WHERE idD = ?)
            """;
            try (PreparedStatement ps = connection.prepareStatement(deleteGroupAwardsSql)) {
                ps.setInt(1, eventId);
                ps.executeUpdate();
            }

            String deleteIndividualAwardsSql = """
                DELETE FROM POJEDINAČNO_PRIZNANJE 
                WHERE idP IN (SELECT idP FROM PRIZNANJE WHERE idD = ?)
            """;
            try (PreparedStatement ps = connection.prepareStatement(deleteIndividualAwardsSql)) {
                ps.setInt(1, eventId);
                ps.executeUpdate();
            }

            // 6. Brisanje priznanja
            String deleteAwardsSql = "DELETE FROM PRIZNANJE WHERE idD = ?";
            try (PreparedStatement ps = connection.prepareStatement(deleteAwardsSql)) {
                ps.setInt(1, eventId);
                ps.executeUpdate();
            }

            // 7. Brisanje učešća alumnista
            String deleteParticipationSql = "DELETE FROM UČESTVUJE WHERE idD = ?";
            try (PreparedStatement ps = connection.prepareStatement(deleteParticipationSql)) {
                ps.setInt(1, eventId);
                ps.executeUpdate();
            }

            // 8. Brisanje sponzorstva
            String deleteSponsorshipSql = "DELETE FROM SPONZORIŠE WHERE idD = ?";
            try (PreparedStatement ps = connection.prepareStatement(deleteSponsorshipSql)) {
                ps.setInt(1, eventId);
                ps.executeUpdate();
            }

            // 9. Brisanje organizacije
            String deleteOrganizationSql = "DELETE FROM ORGANIZUJE WHERE idD = ?";
            try (PreparedStatement ps = connection.prepareStatement(deleteOrganizationSql)) {
                ps.setInt(1, eventId);
                ps.executeUpdate();
            }

            // 10. Brisanje tipova događaja
            String deleteEventTypesSql = "DELETE FROM PRIPADA WHERE idD = ?";
            try (PreparedStatement ps = connection.prepareStatement(deleteEventTypesSql)) {
                ps.setInt(1, eventId);
                ps.executeUpdate();
            }

            // 11. Brisanje samog događaja
            String deleteEventSql = "DELETE FROM DOGAĐAJ WHERE idD = ?";
            try (PreparedStatement ps = connection.prepareStatement(deleteEventSql)) {
                ps.setInt(1, eventId);
                int deletedRows = ps.executeUpdate();
                if (deletedRows == 0) {
                    throw new SQLException("Događaj sa ID " + eventId + " ne postoji!");
                }
            }

            connection.commit();
            return true;

        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Greška pri rollback-u: " + rollbackEx.getMessage());
            }
            System.err.println("Greška pri brisanju događaja: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                System.err.println("Greška pri vraćanju autoCommit: " + e.getMessage());
            }
        }
    }

    @Override
    public boolean registerAlumnusForEventWithAward(int alumnusId, int eventId, String awardName) {
        try {
            connection.setAutoCommit(false);

            // 1. Proveriti da li alumnus postoji
            String checkAlumnusSql = "SELECT COUNT(*) FROM ALUMNUS WHERE idAlumn = ?";
            try (PreparedStatement ps = connection.prepareStatement(checkAlumnusSql)) {
                ps.setInt(1, alumnusId);
                ResultSet rs = ps.executeQuery();
                rs.next();
                if (rs.getInt(1) == 0) {
                    throw new SQLException("Alumnus sa ID " + alumnusId + " ne postoji!");
                }
            }

            // 2. Proveriti da li događaj postoji
            String checkEventSql = "SELECT COUNT(*) FROM DOGAĐAJ WHERE idD = ?";
            try (PreparedStatement ps = connection.prepareStatement(checkEventSql)) {
                ps.setInt(1, eventId);
                ResultSet rs = ps.executeQuery();
                rs.next();
                if (rs.getInt(1) == 0) {
                    throw new SQLException("Događaj sa ID " + eventId + " ne postoji!");
                }
            }

            // 3. Registracija alumnusa za događaj
            String registerSql = "INSERT INTO UČESTVUJE (idAlumn, idD) VALUES (?, ?)";
            try (PreparedStatement ps = connection.prepareStatement(registerSql)) {
                ps.setInt(1, alumnusId);
                ps.setInt(2, eventId);
                ps.executeUpdate();
            }

            // 4. Kreiranje novog priznanja
            String getMaxAwardIdSql = "SELECT COALESCE(MAX(idP), 0) + 1 FROM PRIZNANJE";
            int newAwardId;
            try (PreparedStatement ps = connection.prepareStatement(getMaxAwardIdSql)) {
                ResultSet rs = ps.executeQuery();
                rs.next();
                newAwardId = rs.getInt(1);
            }

            String createAwardSql = "INSERT INTO PRIZNANJE (idP, NazP, idD) VALUES (?, ?, ?)";
            try (PreparedStatement ps = connection.prepareStatement(createAwardSql)) {
                ps.setInt(1, newAwardId);
                ps.setString(2, awardName);
                ps.setInt(3, eventId);
                ps.executeUpdate();
            }

            // 5. Dodavanje kao pojedinačno priznanje
            String createIndividualAwardSql = "INSERT INTO POJEDINAČNO_PRIZNANJE (idP) VALUES (?)";
            try (PreparedStatement ps = connection.prepareStatement(createIndividualAwardSql)) {
                ps.setInt(1, newAwardId);
                ps.executeUpdate();
            }

            // 6. Dodela priznanja alumnusu
            String assignAwardSql = "INSERT INTO DOBIJA_PRIZNANJE (idAlumn, idP) VALUES (?, ?)";
            try (PreparedStatement ps = connection.prepareStatement(assignAwardSql)) {
                ps.setInt(1, alumnusId);
                ps.setInt(2, newAwardId);
                ps.executeUpdate();
            }

            connection.commit();
            return true;

        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Greška pri rollback-u: " + rollbackEx.getMessage());
            }
            System.err.println("Greška pri registraciji alumnusa: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                System.err.println("Greška pri vraćanju autoCommit: " + e.getMessage());
            }
        }
    }

    // Clean up method
    public void close() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.err.println("Greška pri zatvaranju konekcije: " + e.getMessage());
            }
        }
    }
}