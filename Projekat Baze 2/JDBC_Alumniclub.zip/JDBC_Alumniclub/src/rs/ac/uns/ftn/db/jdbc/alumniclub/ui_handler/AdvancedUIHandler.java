package rs.ac.uns.ftn.db.jdbc.alumniclub.ui_handler;

import rs.ac.uns.ftn.db.jdbc.alumniclub.service.AlumnusService;
import rs.ac.uns.ftn.db.jdbc.alumniclub.service.EventService;
import rs.ac.uns.ftn.db.jdbc.alumniclub.service.ReportService;
import rs.ac.uns.ftn.db.jdbc.alumniclub.dto.EventDTO;
import rs.ac.uns.ftn.db.jdbc.alumniclub.dto.AlumnusDTO;

import java.util.*;

public class AdvancedUIHandler {
    private EventService eventService;
    private AlumnusService alumnusService;
    private ReportService reportService;
    private Scanner scanner;

    public AdvancedUIHandler(EventService eventService, AlumnusService alumnusService, ReportService reportService) {
        this.eventService = eventService;
        this.alumnusService = alumnusService;
        this.reportService = reportService;
        this.scanner = new Scanner(System.in);
    }

    public void showMainMenu() {
        while (true) {
            System.out.println("\n" + "=".repeat(50));
            System.out.println("    UNIVERZITETSKO UDRUŽENJE ALUMNISTA");
            System.out.println("=".repeat(50));
            System.out.println("1. Upravljanje događajima");
            System.out.println("2. Upravljanje alumnistima");
            System.out.println("3. Jednostavni izvještaji");
            System.out.println("4. Kompleksni izvještaji");
            System.out.println("5. Transakcije");
            System.out.println("6. Izlaz");
            System.out.print("\nIzaberite opciju (1-6): ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    handleEventMenu();
                    break;
                case 2:
                    handleAlumnusMenu();
                    break;
                case 3:
                    handleSimpleReportsMenu();
                    break;
                case 4:
                    handleComplexReportsMenu();
                    break;
                case 5:
                    handleTransactionsMenu();
                    break;
                case 6:
                    System.out.println("\nHvala što ste koristili sistem!");
                    System.out.println("Doviđenja!");
                    return;
                default:
                    System.out.println("\n❌ Neispravna opcija! Molimo unesite broj od 1 do 6.");
            }
        }
    }

    private void handleEventMenu() {
        while (true) {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("    UPRAVLJANJE DOGAĐAJIMA");
            System.out.println("=".repeat(40));
            System.out.println("1. Prikaži sve događaje");
            System.out.println("2. Prikaži događaj po ID-u");
            System.out.println("3. Dodaj novi događaj");
            System.out.println("4. Ažuriraj događaj");
            System.out.println("5. Obriši događaj");
            System.out.println("6. Nazad na glavni meni");
            System.out.print("\nIzaberite opciju (1-6): ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    showAllEvents();
                    break;
                case 2:
                    showEventById();
                    break;
                case 3:
                    addNewEvent();
                    break;
                case 4:
                    updateEvent();
                    break;
                case 5:
                    deleteEvent();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("\n❌ Neispravna opcija!");
            }
        }
    }

    private void handleAlumnusMenu() {
        while (true) {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("    UPRAVLJANJE ALUMNISTIMA");
            System.out.println("=".repeat(40));
            System.out.println("1. Prikaži sve alumniste");
            System.out.println("2. Prikaži alumnusa po ID-u");
            System.out.println("3. Dodaj novog alumnusa");
            System.out.println("4. Ažuriraj alumnusa");
            System.out.println("5. Obriši alumnusa");
            System.out.println("6. Prikaži alumniste po odseku");
            System.out.println("7. Prikaži alumniste po događaju");
            System.out.println("8. Nazad na glavni meni");
            System.out.print("\nIzaberite opciju (1-8): ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    showAllAlumni();
                    break;
                case 2:
                    showAlumnusById();
                    break;
                case 3:
                    addNewAlumnus();
                    break;
                case 4:
                    updateAlumnus();
                    break;
                case 5:
                    deleteAlumnus();
                    break;
                case 6:
                    showAlumniByDepartment();
                    break;
                case 7:
                    showAlumniByEvent();
                    break;
                case 8:
                    return;
                default:
                    System.out.println("\n❌ Neispravna opcija!");
            }
        }
    }

    private void handleSimpleReportsMenu() {
        while (true) {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("    JEDNOSTAVNI IZVJEŠTAJI");
            System.out.println("=".repeat(40));
            System.out.println("1. Broj alumnista po odseku");
            System.out.println("2. Događaji po univerzitetu");
            System.out.println("3. Najaktivniji alumnisti");
            System.out.println("4. Efikasnost donatora");
            System.out.println("5. Nazad na glavni meni");
            System.out.print("\nIzaberite opciju (1-5): ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    reportService.printAlumniCountByDepartment();
                    pauseForUser();
                    break;
                case 2:
                    showEventsByUniversity();
                    break;
                case 3:
                    reportService.printMostActiveAlumniReport();
                    pauseForUser();
                    break;
                case 4:
                    reportService.printDonorEfficiencyReport();
                    pauseForUser();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("\n❌ Neispravna opcija!");
            }
        }
    }

    private void handleComplexReportsMenu() {
        while (true) {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("    KOMPLEKSNI IZVJEŠTAJI");
            System.out.println("=".repeat(40));
            System.out.println("1. Detaljni izvještaj o događajima");
            System.out.println("2. Analiza aktivnosti po lokacijama");
            System.out.println("3. Hijerarhijska analiza koordinatora");
            System.out.println("4. Mesečni izvještaj aktivnosti");
            System.out.println("5. Nazad na glavni meni");
            System.out.print("\nIzaberite opciju (1-5): ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    reportService.printDetailedEventReport();
                    pauseForUser();
                    break;
                case 2:
                    reportService.printActivityAnalysisByLocation();
                    pauseForUser();
                    break;
                case 3:
                    reportService.printCoordinatorHierarchyAnalysis();
                    pauseForUser();
                    break;
                case 4:
                    reportService.printMonthlyActivityReport();
                    pauseForUser();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("\n❌ Neispravna opcija!");
            }
        }
    }

    private void handleTransactionsMenu() {
        while (true) {
            System.out.println("\n" + "=".repeat(40));
            System.out.println("    TRANSAKCIJE");
            System.out.println("=".repeat(40));
            System.out.println("1. Kreiraj kompletan događaj");
            System.out.println("2. Obriši kompletan događaj");
            System.out.println("3. Registruj alumnusa sa priznanjem");
            System.out.println("4. Nazad na glavni meni");
            System.out.print("\nIzaberite opciju (1-4): ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    createCompleteEvent();
                    break;
                case 2:
                    deleteCompleteEvent();
                    break;
                case 3:
                    registerAlumnusWithAward();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("\n❌ Neispravna opcija!");
            }
        }
    }

    // === Implementacija metoda ===

    private void showAllEvents() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("    SVI DOGAĐAJI U SISTEMU");
        System.out.println("=".repeat(60));

        List<EventDTO> events = eventService.getAllEvents();

        if (events.isEmpty()) {
            System.out.println("❌ Nema događaja u sistemu.");
            return;
        }

        System.out.printf("%-5s %-25s %-30s %-12s%n", "ID", "Naziv", "Opis", "Datum");
        System.out.println("-".repeat(75));

        for (EventDTO event : events) {
            System.out.printf("%-5d %-25s %-30s %-12s%n",
                    event.getIdD(),
                    truncateString(event.getNazD(), 24),
                    truncateString(event.getOpisD(), 29),
                    event.getDatD());
        }

        pauseForUser();
    }

    private void showEventById() {
        System.out.print("\nUnesite ID događaja: ");
        int id = getIntInput();

        EventDTO event = eventService.getEventById(id);
        if (event == null) {
            System.out.println("❌ Događaj sa ID " + id + " nije pronađen!");
            return;
        }

        System.out.println("\n" + "=".repeat(50));
        System.out.println("    DETALJI DOGAĐAJA");
        System.out.println("=".repeat(50));
        System.out.println("ID: " + event.getIdD());
        System.out.println("Naziv: " + event.getNazD());
        System.out.println("Opis: " + event.getOpisD());
        System.out.println("Datum: " + event.getDatD());

        pauseForUser();
    }

    private void addNewEvent() {
        System.out.println("\n" + "=".repeat(40));
        System.out.println("    DODAVANJE NOVOG DOGAĐAJA");
        System.out.println("=".repeat(40));

        System.out.print("ID događaja: ");
        int id = getIntInput();

        System.out.print("Naziv događaja: ");
        String naziv = getStringInput();

        System.out.print("Opis događaja: ");
        String opis = getStringInput();

        System.out.print("Datum događaja (YYYY-MM-DD): ");
        String datum = getStringInput();

        EventDTO event = new EventDTO(id, naziv, opis, datum);

        if (eventService.createEventWithSessions(event, Arrays.asList("Glavna sesija", "Zatvaranje"))) {
            System.out.println("✅ Događaj uspešno dodan!");
        } else {
            System.out.println("❌ Greška pri dodavanju događaja!");
        }

        pauseForUser();
    }

    private void updateEvent() {
        System.out.print("\nUnesite ID događaja za ažuriranje: ");
        int id = getIntInput();

        EventDTO event = eventService.getEventById(id);
        if (event == null) {
            System.out.println("❌ Događaj nije pronađen!");
            return;
        }

        System.out.println("\nTrenutni podaci:");
        System.out.println("Naziv: " + event.getNazD());
        System.out.println("Opis: " + event.getOpisD());
        System.out.println("Datum: " + event.getDatD());

        System.out.print("\nNovi naziv (Enter za zadržavanje): ");
        String naziv = scanner.nextLine();
        if (!naziv.trim().isEmpty()) {
            event.setNazD(naziv);
        }

        System.out.print("Novi opis (Enter za zadržavanje): ");
        String opis = scanner.nextLine();
        if (!opis.trim().isEmpty()) {
            event.setOpisD(opis);
        }

        System.out.print("Novi datum (Enter za zadržavanje): ");
        String datum = scanner.nextLine();
        if (!datum.trim().isEmpty()) {
            event.setDatD(datum);
        }

        if (eventService.updateEvent(event)) {
            System.out.println("✅ Događaj uspešno ažuriran!");
        } else {
            System.out.println("❌ Greška pri ažuriranju događaja!");
        }

        pauseForUser();
    }

    private void deleteEvent() {
        System.out.print("\nUnesite ID događaja za brisanje: ");
        int id = getIntInput();

        EventDTO event = eventService.getEventById(id);
        if (event == null) {
            System.out.println("❌ Događaj sa ID " + id + " ne postoji!");
            return;
        }

        System.out.println("\nDa li ste sigurni da želite da obrišete događaj:");
        System.out.println("'" + event.getNazD() + "' (" + event.getDatD() + ")?");
        System.out.print("Unesite 'DA' za potvrdu: ");

        String potvrda = getStringInput();
        if (!"DA".equals(potvrda.toUpperCase())) {
            System.out.println("Brisanje otkazano.");
            return;
        }

        if (eventService.deleteEvent(id)) {
            System.out.println("✅ Događaj uspešno obrisan!");
        } else {
            System.out.println("❌ Greška pri brisanju događaja!");
        }

        pauseForUser();
    }

    private void showAllAlumni() {
        System.out.println("\n" + "=".repeat(70));
        System.out.println("    SVI ALUMNISTI U SISTEMU");
        System.out.println("=".repeat(70));

        List<AlumnusDTO> alumni = alumnusService.getAllAlumni();

        if (alumni.isEmpty()) {
            System.out.println("❌ Nema alumnista u sistemu.");
            return;
        }

        System.out.printf("%-5s %-25s %-30s%n", "ID", "Ime", "Odsek");
        System.out.println("-".repeat(65));

        for (AlumnusDTO alumnus : alumni) {
            System.out.printf("%-5d %-25s %-30s%n",
                    alumnus.getIdAlumn(),
                    truncateString(alumnus.getNazAlumn(), 24),
                    truncateString(alumnus.getNazAlOd(), 29));
        }

        pauseForUser();
    }

    private void showAlumnusById() {
        System.out.print("\nUnesite ID alumnusa: ");
        int id = getIntInput();

        AlumnusDTO alumnus = alumnusService.getAlumnusById(id);
        if (alumnus == null) {
            System.out.println("❌ Alumnus sa ID " + id + " nije pronađen!");
            return;
        }

        System.out.println("\n" + "=".repeat(50));
        System.out.println("    DETALJI ALUMNUSA");
        System.out.println("=".repeat(50));
        System.out.println("ID: " + alumnus.getIdAlumn());
        System.out.println("Ime: " + alumnus.getNazAlumn());
        System.out.println("ID Odseka: " + alumnus.getIdAlOd());
        System.out.println("Naziv Odseka: " + alumnus.getNazAlOd());

        pauseForUser();
    }

    private void addNewAlumnus() {
        System.out.println("\n" + "=".repeat(40));
        System.out.println("    DODAVANJE NOVOG ALUMNUSA");
        System.out.println("=".repeat(40));

        System.out.print("ID alumnusa: ");
        int id = getIntInput();

        System.out.print("Ime alumnusa: ");
        String naziv = getStringInput();

        System.out.print("ID odseka: ");
        int odsetId = getIntInput();

        AlumnusDTO alumnus = new AlumnusDTO(id, naziv, odsetId, "");

        if (alumnusService.createAlumnus(alumnus)) {
            System.out.println("✅ Alumnus uspešno dodan!");
        } else {
            System.out.println("❌ Greška pri dodavanju alumnusa!");
        }

        pauseForUser();
    }

    private void updateAlumnus() {
        System.out.print("\nUnesite ID alumnusa za ažuriranje: ");
        int id = getIntInput();

        AlumnusDTO alumnus = alumnusService.getAlumnusById(id);
        if (alumnus == null) {
            System.out.println("❌ Alumnus nije pronađen!");
            return;
        }

        System.out.println("\nTrenutni podaci:");
        System.out.println("Ime: " + alumnus.getNazAlumn());
        System.out.println("ID Odseka: " + alumnus.getIdAlOd());

        System.out.print("\nNovo ime (Enter za zadržavanje): ");
        String naziv = scanner.nextLine();
        if (!naziv.trim().isEmpty()) {
            alumnus.setNazAlumn(naziv);
        }

        System.out.print("Novi ID odseka (0 za zadržavanje): ");
        String odsetInput = scanner.nextLine();
        if (!odsetInput.trim().isEmpty() && !odsetInput.equals("0")) {
            try {
                int odsetId = Integer.parseInt(odsetInput);
                alumnus.setIdAlOd(odsetId);
            } catch (NumberFormatException e) {
                System.out.println("⚠️ Neispravna vrednost za ID odseka, zadržavam postojeću.");
            }
        }

        if (alumnusService.updateAlumnus(alumnus)) {
            System.out.println("✅ Alumnus uspešno ažuriran!");
        } else {
            System.out.println("❌ Greška pri ažuriranju alumnusa!");
        }

        pauseForUser();
    }

    private void deleteAlumnus() {
        System.out.print("\nUnesite ID alumnusa za brisanje: ");
        int id = getIntInput();

        AlumnusDTO alumnus = alumnusService.getAlumnusById(id);
        if (alumnus == null) {
            System.out.println("❌ Alumnus sa ID " + id + " ne postoji!");
            return;
        }

        System.out.println("\nDa li ste sigurni da želite da obrišete alumnusa:");
        System.out.println("'" + alumnus.getNazAlumn() + "'?");
        System.out.print("Unesite 'DA' za potvrdu: ");

        String potvrda = getStringInput();
        if (!"DA".equals(potvrda.toUpperCase())) {
            System.out.println("Brisanje otkazano.");
            return;
        }

        if (alumnusService.deleteAlumnus(id)) {
            System.out.println("✅ Alumnus uspešno obrisan!");
        } else {
            System.out.println("❌ Greška pri brisanju alumnusa!");
        }

        pauseForUser();
    }

    private void showAlumniByDepartment() {
        System.out.print("\nUnesite ID odseka: ");
        int departmentId = getIntInput();

        List<AlumnusDTO> alumni = alumnusService.getAlumniByDepartment(departmentId);

        if (alumni.isEmpty()) {
            System.out.println("❌ Nema alumnista u odseku sa ID " + departmentId);
            return;
        }

        System.out.println("\n=== ALUMNISTI ODSEKA " + departmentId + " ===");
        System.out.printf("%-5s %-25s %-30s%n", "ID", "Ime", "Odsek");
        System.out.println("-".repeat(65));

        for (AlumnusDTO alumnus : alumni) {
            System.out.printf("%-5d %-25s %-30s%n",
                    alumnus.getIdAlumn(),
                    truncateString(alumnus.getNazAlumn(), 24),
                    truncateString(alumnus.getNazAlOd(), 29));
        }

        pauseForUser();
    }

    private void showAlumniByEvent() {
        System.out.print("\nUnesite ID događaja: ");
        int eventId = getIntInput();

        List<AlumnusDTO> alumni = alumnusService.getAlumniByEvent(eventId);

        if (alumni.isEmpty()) {
            System.out.println("❌ Nema alumnista na događaju sa ID " + eventId);
            return;
        }

        System.out.println("\n=== ALUMNISTI NA DOGAĐAJU " + eventId + " ===");
        System.out.printf("%-5s %-25s %-30s%n", "ID", "Ime", "Odsek");
        System.out.println("-".repeat(65));

        for (AlumnusDTO alumnus : alumni) {
            System.out.printf("%-5d %-25s %-30s%n",
                    alumnus.getIdAlumn(),
                    truncateString(alumnus.getNazAlumn(), 24),
                    truncateString(alumnus.getNazAlOd(), 29));
        }

        pauseForUser();
    }

    private void showEventsByUniversity() {
        System.out.print("\nUnesite ID univerziteta: ");
        int universityId = getIntInput();

        eventService.getEventCountByUniversity(universityId);
        pauseForUser();
    }

    private void createCompleteEvent() {
        // Simply call the service method which will handle everything
        if (reportService.createCompleteEventTransaction()) {
            // Success message already printed by service
        } else {
            // Error message already printed by service
        }
        pauseForUser();
    }

    private void deleteCompleteEvent() {
        System.out.print("\nUnesite ID događaja za kompletno brisanje: ");
        int eventId = getIntInput();

        System.out.println("\n⚠️  UPOZORENJE: Ova operacija će obrisati:");
        System.out.println("   - Događaj sa svim sesijama");
        System.out.println("   - Sve aktivnosti i koordinacije");
        System.out.println("   - Sva priznanja");
        System.out.println("   - Sva učešća alumnista");
        System.out.println("   - Sve sponzorske veze");

        System.out.print("\nDa li ste sigurni? Unesite 'OBRISI' za potvrdu: ");
        String potvrda = getStringInput();

        if (!"OBRISI".equals(potvrda.toUpperCase())) {
            System.out.println("Brisanje otkazano.");
            return;
        }

        if (reportService.deleteCompleteEventTransaction(eventId)) {
            System.out.println("✅ Događaj i svi povezani podaci uspešno obrisani!");
        } else {
            System.out.println("❌ Greška pri brisanju događaja!");
        }

        pauseForUser();
    }

    private void registerAlumnusWithAward() {
        System.out.println("\n" + "=".repeat(50));
        System.out.println("    REGISTRACIJA ALUMNUSA SA PRIZNANJEM");
        System.out.println("=".repeat(50));

        System.out.print("ID alumnusa: ");
        int alumnusId = getIntInput();

        System.out.print("ID događaja: ");
        int eventId = getIntInput();

        System.out.print("Naziv priznanja: ");
        String awardName = getStringInput();

        if (reportService.registerAlumnusWithAward(alumnusId, eventId, awardName)) {
            System.out.println("✅ Alumnus uspešno registrovan i dodeljena mu je nagrada!");
        } else {
            System.out.println("❌ Greška pri registraciji alumnusa!");
        }

        pauseForUser();
    }

    // === Pomoćne metode ===

    private int getIntInput() {
        while (true) {
            try {
                int value = scanner.nextInt();
                scanner.nextLine(); // consume newline
                return value;
            } catch (Exception e) {
                System.out.print("❌ Molimo unesite valjan broj: ");
                scanner.nextLine(); // clear invalid input
            }
        }
    }

    private String getStringInput() {
        return scanner.nextLine().trim();
    }

    private void pauseForUser() {
        System.out.print("\nPritisnite Enter za nastavak...");
        scanner.nextLine();
    }

    private String truncateString(String str, int maxLength) {
        if (str == null) return "";
        if (str.length() <= maxLength) return str;
        return str.substring(0, maxLength - 3) + "...";
    }
}