package rs.ac.uns.ftn.db.jdbc.alumniclub.service;

import rs.ac.uns.ftn.db.jdbc.alumniclub.dao.AlumnusDAO;
import rs.ac.uns.ftn.db.jdbc.alumniclub.dto.AlumnusDTO;

import java.util.List;

public class AlumnusService {
    private AlumnusDAO alumnusDAO;

    public AlumnusService(AlumnusDAO alumnusDAO) {
        this.alumnusDAO = alumnusDAO;
    }

    public List<AlumnusDTO> getAllAlumni() {
        return alumnusDAO.findAll();
    }

    public AlumnusDTO getAlumnusById(int id) {
        return alumnusDAO.findById(id);
    }

    public boolean createAlumnus(AlumnusDTO alumnus) {
        return alumnusDAO.insert(alumnus);
    }

    public boolean updateAlumnus(AlumnusDTO alumnus) {
        return alumnusDAO.update(alumnus);
    }

    public boolean deleteAlumnus(int id) {
        return alumnusDAO.delete(id);
    }

    public List<AlumnusDTO> getAlumniByDepartment(int departmentId) {
        return alumnusDAO.findAlumniByDepartment(departmentId);
    }

    public List<AlumnusDTO> getAlumniByEvent(int eventId) {
        return alumnusDAO.findAlumniByEvent(eventId);
    }
}