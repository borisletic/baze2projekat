package rs.ac.uns.ftn.db.jdbc.alumniclub.service;

import rs.ac.uns.ftn.db.jdbc.alumniclub.dao.ReportDAO;
import rs.ac.uns.ftn.db.jdbc.alumniclub.dao.ReportDAOImpl;
import rs.ac.uns.ftn.db.jdbc.alumniclub.dao.TransactionDAO;
import rs.ac.uns.ftn.db.jdbc.alumniclub.dao.TransactionDAOImpl;
import rs.ac.uns.ftn.db.jdbc.alumniclub.dto.EventDTO;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Service klasa za kompleksne izvještaje i transakcije
 * Koristi MySQL bazu podataka sa DatabaseConnection klasom
 *
 * @author Boris Letić RA 207/2021
 */
public class ReportService {
    private ReportDAO reportDAO;
    private TransactionDAO transactionDAO;
    private Scanner scanner;

    public ReportService() {
        this.reportDAO = new ReportDAOImpl();
        this.transactionDAO = new TransactionDAOImpl();
        this.scanner = new Scanner(System.in);
    }

    public ReportService(ReportDAO reportDAO, TransactionDAO transactionDAO) {
        this.reportDAO = reportDAO;
        this.transactionDAO = transactionDAO;
        this.scanner = new Scanner(System.in);
    }

    // ================================================================
    // JEDNOSTAVAN UPIT - spajanje 2 tabele sa agregacionim funkcijama
    // ================================================================
    public void printAlumniCountByDepartment() {
        System.out.println("\n" + "=".repeat(70));
        System.out.println("    BROJ ALUMNISTA PO ODSEKU (JEDNOSTAVAN UPIT)");
        System.out.println("=".repeat(70));

        List<Map<String, Object>> results = reportDAO.getAlumniCountByDepartment();

        if (results.isEmpty()) {
            System.out.println("❌ Nema podataka o alumnistima u bazi.");
            return;
        }

        System.out.printf("%-30s %15s %20s%n", "Naziv odseka", "Broj alumnista", "Prosečni ID");
        System.out.println("-".repeat(70));

        int ukupnoAlumnista = 0;
        for (Map<String, Object> row : results) {
            System.out.printf("%-30s %15d %20.2f%n",
                    truncateString((String) row.get("naziv_odseka"), 29),
                    row.get("broj_alumnista"),
                    row.get("prosecni_id"));

            ukupnoAlumnista += (Integer) row.get("broj_alumnista");
        }

        // Dodatna agregacijska analiza
        System.out.println("-".repeat(70));
        System.out.println("\n📊 AGREGACIJSKA STATISTIKA:");
        System.out.println("   • Ukupno odseka: " + results.size());
        System.out.println("   • Ukupno alumnista: " + ukupnoAlumnista);
        System.out.println("   • Prosečno alumnista po odseku: " +
                String.format("%.2f", (double) ukupnoAlumnista / results.size()));

        // Nalaženje odseka sa najviše alumnista
        Map<String, Object> maxOdsek = results.stream()
                .max((r1, r2) -> Integer.compare((Integer) r1.get("broj_alumnista"),
                        (Integer) r2.get("broj_alumnista")))
                .orElse(null);

        if (maxOdsek != null) {
            System.out.println("   • Najveći odsek: " + maxOdsek.get("naziv_odseka") +
                    " (" + maxOdsek.get("broj_alumnista") + " alumnista)");
        }
    }

    // ================================================================
    // KOMPLEKSAN UPIT 1 - spoljno spajanje 6 tabela sa agregacijama
    // ================================================================
    public void printDetailedEventReport() {
        System.out.println("\n" + "=".repeat(130));
        System.out.println("    DETALJNI IZVJEŠTAJ O DOGAĐAJIMA (KOMPLEKSAN UPIT 1)");
        System.out.println("=".repeat(130));

        List<Map<String, Object>> results = reportDAO.getDetailedEventReport();

        if (results.isEmpty()) {
            System.out.println("❌ Nema podataka o događajima u bazi.");
            return;
        }

        System.out.printf("%-25s %-12s %-20s %8s %8s %8s %8s %-15s%n",
                "Događaj", "Datum", "Univerzitet", "Učesnici", "Sesije", "Donatori", "Priznanja", "Kategorija");
        System.out.println("-".repeat(130));

        int ukupnoDogadjaja = 0;
        int ukupnoUcesnika = 0;

        for (Map<String, Object> row : results) {
            System.out.printf("%-25s %-12s %-20s %8d %8d %8d %8d %-15s%n",
                    truncateString((String) row.get("naziv_dogadjaja"), 24),
                    row.get("datum_dogadjaja"),
                    truncateString((String) row.get("organizator_univerzitet"), 19),
                    row.get("broj_ucesnika"),
                    row.get("broj_sesija"),
                    row.get("broj_donatora"),
                    row.get("broj_priznanja"),
                    row.get("kategorija_dogadjaja"));

            ukupnoDogadjaja++;
            ukupnoUcesnika += (Integer) row.get("broj_ucesnika");
        }

        System.out.println("-".repeat(130));
        System.out.println("\n📊 AGREGACIJSKA ANALIZA:");
        System.out.println("   • Ukupno događaja: " + ukupnoDogadjaja);
        System.out.println("   • Ukupno učesnika: " + ukupnoUcesnika);
        System.out.println("   • Prosečno učesnika po događaju: " +
                String.format("%.2f", (double) ukupnoUcesnika / ukupnoDogadjaja));

        // Analiza po kategorijama
        long velikihDogadjaja = results.stream()
                .filter(row -> "Veliki događaj".equals(row.get("kategorija_dogadjaja")))
                .count();

        System.out.println("   • Velikih događaja (5+ učesnika): " + velikihDogadjaja);
        System.out.println("   • Procenat velikih događaja: " +
                String.format("%.1f%%", (velikihDogadjaja * 100.0) / ukupnoDogadjaja));
    }

    // ================================================================
    // KOMPLEKSAN UPIT 2 - spoljno spajanje 5 tabela sa kompleksnim agregacijama
    // ================================================================
    public void printActivityAnalysisByLocation() {
        System.out.println("\n" + "=".repeat(120));
        System.out.println("    ANALIZA AKTIVNOSTI PO LOKACIJAMA (KOMPLEKSAN UPIT 2)");
        System.out.println("=".repeat(120));

        List<Map<String, Object>> results = reportDAO.getActivityAnalysisByLocation();

        if (results.isEmpty()) {
            System.out.println("❌ Nema podataka o aktivnostima u bazi.");
            return;
        }

        System.out.printf("%-15s %-20s %12s %10s %10s %15s %-12s %-12s%n",
                "Grad", "Lokacija", "Aktivnosti", "Sesije", "Događaji", "Koordinatori", "Prvi", "Poslednji");
        System.out.println("-".repeat(120));

        int ukupnoAktivnosti = 0;

        for (Map<String, Object> row : results) {
            System.out.printf("%-15s %-20s %12d %10d %10d %15d %-12s %-12s%n",
                    truncateString((String) row.get("grad"), 14),
                    truncateString((String) row.get("lokacija"), 19),
                    row.get("broj_aktivnosti"),
                    row.get("broj_sesija"),
                    row.get("broj_dogadjaja"),
                    row.get("broj_koordinatora"),
                    row.get("prvi_dogadjaj"),
                    row.get("poslednji_dogadjaj"));

            ukupnoAktivnosti += (Integer) row.get("broj_aktivnosti");
        }

        System.out.println("-".repeat(120));
        System.out.println("\n📊 PROSTORNA ANALIZA:");
        System.out.println("   • Ukupno lokacija: " + results.size());
        System.out.println("   • Ukupno aktivnosti: " + ukupnoAktivnosti);
        System.out.println("   • Prosečno aktivnosti po lokaciji: " +
                String.format("%.2f", (double) ukupnoAktivnosti / results.size()));

        // Najaktivnija lokacija
        Map<String, Object> najaktivnija = results.stream()
                .max((r1, r2) -> Integer.compare((Integer) r1.get("broj_aktivnosti"),
                        (Integer) r2.get("broj_aktivnosti")))
                .orElse(null);

        if (najaktivnija != null) {
            System.out.println("   • Najaktivnija lokacija: " + najaktivnija.get("lokacija") +
                    " u gradu " + najaktivnija.get("grad") +
                    " (" + najaktivnija.get("broj_aktivnosti") + " aktivnosti)");
        }
    }

    // ================================================================
    // KOMPLEKSAN UPIT 3 - hijerarhijska analiza sa self-join
    // ================================================================
    public void printCoordinatorHierarchyAnalysis() {
        System.out.println("\n" + "=".repeat(90));
        System.out.println("    HIJERARHIJSKA ANALIZA KOORDINATORA (KOMPLEKSAN UPIT 3)");
        System.out.println("=".repeat(90));

        List<Map<String, Object>> results = reportDAO.getCoordinatorHierarchyAnalysis();

        if (results.isEmpty()) {
            System.out.println("❌ Nema podataka o koordinatorima u bazi.");
            return;
        }

        System.out.printf("%-20s %-20s %12s %12s %-20s%n",
                "Koordinator", "Nadređeni", "Podređeni", "Aktivnosti", "Tip");
        System.out.println("-".repeat(90));

        int glavnihKoordinatora = 0;
        int srednjihMenadžera = 0;
        int izvršnihKoordinatora = 0;

        for (Map<String, Object> row : results) {
            System.out.printf("%-20s %-20s %12d %12d %-20s%n",
                    truncateString((String) row.get("koordinator"), 19),
                    row.get("nadredjeni_koordinator") != null ?
                            truncateString((String) row.get("nadredjeni_koordinator"), 19) : "N/A",
                    row.get("broj_podredjenih"),
                    row.get("broj_aktivnosti"),
                    row.get("tip_koordinatora"));

            // Brojanje po tipovima
            String tip = (String) row.get("tip_koordinatora");
            switch (tip) {
                case "Glavni koordinator": glavnihKoordinatora++; break;
                case "Srednji menadžer": srednjihMenadžera++; break;
                case "Izvršni koordinator": izvršnihKoordinatora++; break;
            }
        }

        System.out.println("-".repeat(90));
        System.out.println("\n📊 HIJERARHIJSKA ANALIZA:");
        System.out.println("   • Ukupno koordinatora: " + results.size());
        System.out.println("   • Glavnih koordinatora: " + glavnihKoordinatora);
        System.out.println("   • Srednjih menadžera: " + srednjihMenadžera);
        System.out.println("   • Izvršnih koordinatora: " + izvršnihKoordinatora);
        System.out.println("   • Prosečna hijerarhijska dubina: " +
                String.format("%.1f nivoa", 1.0 + (srednjihMenadžera * 1.0) / glavnihKoordinatora));
    }

    // ================================================================
    // DODATNI IZVJEŠTAJI
    // ================================================================
    public void printMostActiveAlumniReport() {
        System.out.println("\n" + "=".repeat(85));
        System.out.println("    NAJAKTIVNIJI ALUMNISTI");
        System.out.println("=".repeat(85));

        List<Map<String, Object>> results = reportDAO.getMostActiveAlumniReport();

        if (results.isEmpty()) {
            System.out.println("❌ Nema aktivnih alumnista u bazi.");
            return;
        }

        System.out.printf("%-20s %-25s %10s %10s %-15s%n",
                "Alumnus", "Odsek", "Događaji", "Priznanja", "Aktivnost");
        System.out.println("-".repeat(85));

        for (Map<String, Object> row : results) {
            System.out.printf("%-20s %-25s %10d %10d %-15s%n",
                    truncateString((String) row.get("alumnus"), 19),
                    truncateString((String) row.get("odsek"), 24),
                    row.get("broj_dogadjaja"),
                    row.get("broj_priznanja"),
                    row.get("nivo_aktivnosti"));
        }
    }

    public void printDonorEfficiencyReport() {
        System.out.println("\n" + "=".repeat(85));
        System.out.println("    EFIKASNOST DONATORA");
        System.out.println("=".repeat(85));

        List<Map<String, Object>> results = reportDAO.getDonorEfficiencyReport();

        if (results.isEmpty()) {
            System.out.println("❌ Nema podataka o donatorima u bazi.");
            return;
        }

        System.out.printf("%-20s %15s %20s %25s%n",
                "Donator", "Događaji", "Ukupno alumnista", "Prosek po događaju");
        System.out.println("-".repeat(85));

        for (Map<String, Object> row : results) {
            System.out.printf("%-20s %15d %20d %25.2f%n",
                    truncateString((String) row.get("donator"), 19),
                    row.get("broj_sponzorisanih_dogadjaja"),
                    row.get("ukupno_dostignuto_alumnista"),
                    row.get("prosecno_alumnista_po_dogadjaju"));
        }
    }

    public void printMonthlyActivityReport() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("    MESEČNI IZVJEŠTAJ AKTIVNOSTI");
        System.out.println("=".repeat(60));

        List<Map<String, Object>> results = reportDAO.getMonthlyActivityReport();

        if (results.isEmpty()) {
            System.out.println("❌ Nema podataka o mesečnim aktivnostima.");
            return;
        }

        System.out.printf("%8s %-12s %10s %10s %10s%n",
                "Godina", "Mesec", "Događaji", "Učesnici", "Sesije");
        System.out.println("-".repeat(60));

        for (Map<String, Object> row : results) {
            System.out.printf("%8d %-12s %10d %10d %10d%n",
                    row.get("godina"),
                    truncateString((String) row.get("naziv_meseca"), 11),
                    row.get("broj_dogadjaja"),
                    row.get("broj_ucesnika"),
                    row.get("broj_sesija"));
        }
    }

    // ================================================================
    // TRANSAKCIJSKE METODE
    // ================================================================

    /**
     * TRANSAKCIJA 1 - Kreiranje kompletnog događaja sa sesijama
     * This method is called when user selects option from menu - it collects all data
     *
     * @return
     */
    public boolean createCompleteEventTransaction() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("    KREIRANJE KOMPLETNOG DOGAĐAJA (TRANSAKCIJA 1)");
        System.out.println("=".repeat(60));

        try {
            System.out.print("ID događaja: ");
            int eventId = getIntInput();

            System.out.print("Naziv događaja: ");
            String naziv = scanner.nextLine();

            System.out.print("Opis događaja: ");
            String opis = scanner.nextLine();

            System.out.print("Datum događaja (YYYY-MM-DD): ");
            String datum = scanner.nextLine();

            System.out.print("ID univerziteta organizatora: ");
            int universityId = getIntInput();

            System.out.print("ID tipa događaja: ");
            int eventTypeId = getIntInput();

            System.out.print("Broj sesija: ");
            int brojSesija = getIntInput();

            List<String> sessions = new java.util.ArrayList<>();
            for (int i = 1; i <= brojSesija; i++) {
                System.out.print("Opis sesije " + i + ": ");
                sessions.add(scanner.nextLine());
            }

            // Create EventDTO with the provided ID
            EventDTO event = new EventDTO();
            event.setIdD(eventId);  // IMPORTANT: Set the ID that user provided
            event.setNazD(naziv);
            event.setOpisD(opis);
            event.setDatD(datum);

            boolean success = transactionDAO.createCompleteEvent(event, universityId, eventTypeId, sessions);

            if (success) {
                System.out.println("✅ Kompletan događaj uspešno kreiran sa ID: " + event.getIdD());
                System.out.println("   📝 Kreiran događaj: " + naziv);
                System.out.println("   🏛️  Organizator: Univerzitet ID " + universityId);
                System.out.println("   📅 Datum: " + datum);
                System.out.println("   🎯 Broj sesija: " + sessions.size());
                return true;
            } else {
                System.out.println("❌ Greška pri kreiranju kompletnog događaja!");
                return false;
            }
        } catch (Exception e) {
            System.err.println("❌ Greška pri unosu podataka: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Creates a complete event with provided data (called from UI)
     * This is used when data is already collected by UI
     */
    public boolean createCompleteEventWithData(EventDTO event, int universityId, int eventTypeId, List<String> sessions) {
        return transactionDAO.createCompleteEvent(event, universityId, eventTypeId, sessions);
    }

    /**
     * TRANSAKCIJA 2 - Kompletno brisanje događaja
     *
     * @param eventId ID događaja za brisanje
     * @return true ako je uspešno, false inače
     */
    public boolean deleteCompleteEventTransaction(int eventId) {
        //System.out.println("\n" + "=".repeat(60));
        //System.out.println("    KOMPLETNO BRISANJE DOGAĐAJA (TRANSAKCIJA 2)");
        //System.out.println("=".repeat(60));

        try {
            boolean success = transactionDAO.deleteCompleteEvent(eventId);

            if (success) {
                System.out.println("✅ Događaj ID " + eventId + " i svi povezani podaci uspešno obrisani!");
                return true;
            } else {
                System.out.println("❌ Greška pri brisanju događaja!");
                return false;
            }
        } catch (Exception e) {
            System.err.println("❌ Greška pri brisanju događaja: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * TRANSAKCIJA 3 - Registracija alumnusa sa dodjelom priznanja
     */
    public void registerAlumnusWithAwardTransaction() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("    REGISTRACIJA ALUMNUSA SA PRIZNANJEM (TRANSAKCIJA 3)");
        System.out.println("=".repeat(60));

        try {
            System.out.print("ID alumnusa: ");
            int alumnusId = getIntInput();

            System.out.print("ID događaja: ");
            int eventId = getIntInput();

            System.out.print("Naziv priznanja: ");
            String awardName = scanner.nextLine();

            if (transactionDAO.registerAlumnusForEventWithAward(alumnusId, eventId, awardName)) {
                System.out.println("✅ Alumnus ID " + alumnusId + " uspešno registrovan!");
                System.out.println("   🎉 Dodeljena nagrada: " + awardName);
                System.out.println("   📋 Na događaju ID: " + eventId);
            } else {
                System.out.println("❌ Greška pri registraciji alumnusa!");
            }
        } catch (Exception e) {
            System.err.println("❌ Greška pri unosu podataka: " + e.getMessage());
        }
    }

    // ================================================================
    // POMOĆNE METODE
    // ================================================================

    /**
     * Skraćuje string na zadatu dužinu
     */
    private String truncateString(String str, int maxLength) {
        if (str == null) return "N/A";
        if (str.length() <= maxLength) return str;
        return str.substring(0, maxLength - 3) + "...";
    }

    /**
     * Bezbedni unos celog broja
     */
    private int getIntInput() {
        while (true) {
            try {
                int value = scanner.nextInt();
                scanner.nextLine(); // consume newline
                return value;
            } catch (Exception e) {
                System.out.print("❌ Molimo unesite valjan broj: ");
                scanner.nextLine(); // clear invalid input
            }
        }
    }

    /**
     * Prikazuje statistiku o sistemu
     */
    public void printSystemStatistics() {
        System.out.println("\n" + "=".repeat(70));
        System.out.println("    SISTEMSKA STATISTIKA");
        System.out.println("=".repeat(70));

        // Ova metoda može da pozove sve ostale izvještaje radi dobijanja opšte slike
        System.out.println("📊 Generisanje sistemske statistike...");

        // Pozovi sve glavne izvještaje
        printAlumniCountByDepartment();
        printDetailedEventReport();
        printActivityAnalysisByLocation();
        printCoordinatorHierarchyAnalysis();

        System.out.println("\n✅ Sistemska analiza završena!");
    }

    public boolean registerAlumnusWithAward(int alumnusId, int eventId, String awardName) {
        return false;
    }

}