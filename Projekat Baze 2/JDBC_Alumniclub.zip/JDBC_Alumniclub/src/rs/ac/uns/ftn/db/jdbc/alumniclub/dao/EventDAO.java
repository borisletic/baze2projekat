package rs.ac.uns.ftn.db.jdbc.alumniclub.dao;

import rs.ac.uns.ftn.db.jdbc.alumniclub.dto.EventDTO;

import java.util.List;

public interface EventDAO {
    List<EventDTO> findAll();
    EventDTO findById(int id);
    boolean insert(EventDTO event);
    boolean update(EventDTO event);
    boolean delete(int id);
    List<EventDTO> findEventsByUniversity(int universityId);
    List<EventDTO> findUpcomingEvents();
}