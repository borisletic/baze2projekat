package rs.ac.uns.ftn.db.jdbc.alumniclub.dto;

public class AlumnusDTO {
    private int idAlumn;
    private String nazAlumn;
    private int idAlOd;
    private String nazAlOd;

    public AlumnusDTO() {}

    public AlumnusDTO(int idAlumn, String nazAlumn, int idAlOd, String nazAlOd) {
        this.idAlumn = idAlumn;
        this.nazAlumn = nazAlumn;
        this.idAlOd = idAlOd;
        this.nazAlOd = nazAlOd;
    }

    // Getteri i setteri
    public int getIdAlumn() { return idAlumn; }
    public void setIdAlumn(int idAlumn) { this.idAlumn = idAlumn; }

    public String getNazAlumn() { return nazAlumn; }
    public void setNazAlumn(String nazAlumn) { this.nazAlumn = nazAlumn; }

    public int getIdAlOd() { return idAlOd; }
    public void setIdAlOd(int idAlOd) { this.idAlOd = idAlOd; }

    public String getNazAlOd() { return nazAlOd; }
    public void setNazAlOd(String nazAlOd) { this.nazAlOd = nazAlOd; }

    @Override
    public String toString() {
        return "Alumnus{" +
                "id=" + idAlumn +
                ", naziv='" + nazAlumn + '\'' +
                ", odsek='" + nazAlOd + '\'' +
                '}';
    }
}