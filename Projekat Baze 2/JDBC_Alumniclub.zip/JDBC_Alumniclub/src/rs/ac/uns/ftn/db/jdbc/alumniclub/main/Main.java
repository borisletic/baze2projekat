package rs.ac.uns.ftn.db.jdbc.alumniclub.main;

import rs.ac.uns.ftn.db.jdbc.alumniclub.dao.*;
import rs.ac.uns.ftn.db.jdbc.alumniclub.service.AlumnusService;
import rs.ac.uns.ftn.db.jdbc.alumniclub.service.EventService;
import rs.ac.uns.ftn.db.jdbc.alumniclub.connection.*;
import rs.ac.uns.ftn.db.jdbc.alumniclub.service.ReportService;
import rs.ac.uns.ftn.db.jdbc.alumniclub.ui_handler.AdvancedUIHandler;

import java.sql.Connection;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        System.out.println("🚀 Pokretanje aplikacije...");

        try {
            // Uspostavljanje konekcije sa bazom podataka
            Connection connection = DatabaseConnection.getConnection();
            System.out.println("✅ Uspešno povezano sa bazom podataka!");

            // Kreiranje DAO objekata
            EventDAO eventDAO = new EventDAOImpl(connection);
            AlumnusDAO alumnusDAO = new AlumnusDAOImpl(connection);

            // Based on the error and ReportService constructor, ReportDAOImpl and TransactionDAOImpl
            // likely don't take connection parameters in their constructors
            ReportDAO reportDAO = new ReportDAOImpl();
            TransactionDAO transactionDAO = new TransactionDAOImpl();

            // Kreiranje Service objekata
            EventService eventService = new EventService(eventDAO, alumnusDAO);
            AlumnusService alumnusService = new AlumnusService(alumnusDAO);
            ReportService reportService = new ReportService(reportDAO, transactionDAO);

            // Kreiranje naprednog UI Handler-a
            AdvancedUIHandler uiHandler = new AdvancedUIHandler(eventService, alumnusService, reportService);

            // Pokretanje glavnog menija
            System.out.println("✅ Sistem spreman za rad!");
            uiHandler.showMainMenu();

            // Zatvaranje konekcije
            connection.close();
            System.out.println("✅ Konekcija sa bazom podataka zatvorena.");

        } catch (SQLException e) {
            System.err.println("❌ Greška pri povezivanju sa bazom podataka:");
            System.err.println("   " + e.getMessage());
            System.err.println("\n🔧 Proverite:");
            System.err.println("   - Da li je MySQL server pokrenut?");
            System.err.println("   - Da li su korisničko ime i lozinka ispravni?");
            System.err.println("   - Da li baza podataka 'alumni_db' postoji?");
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("❌ Neočekivana greška: " + e.getMessage());
            e.printStackTrace();
        }
    }
}