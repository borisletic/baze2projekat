package rs.ac.uns.ftn.db.jdbc.alumniclub.dto;

public class EventDTO {
    private int idD;
    private String nazD;
    private String opisD;
    private String datD;

    // Konstruktori
    public EventDTO() {}

    public EventDTO(int idD, String nazD, String opisD, String datD) {
        this.idD = idD;
        this.nazD = nazD;
        this.opisD = opisD;
        this.datD = datD;
    }

    // Getteri i setteri
    public int getIdD() { return idD; }
    public void setIdD(int idD) { this.idD = idD; }

    public String getNazD() { return nazD; }
    public void setNazD(String nazD) { this.nazD = nazD; }

    public String getOpisD() { return opisD; }
    public void setOpisD(String opisD) { this.opisD = opisD; }

    public String getDatD() { return datD; }
    public void setDatD(String datD) { this.datD = datD; }

    @Override
    public String toString() {
        return "Event{" +
                "id=" + idD +
                ", naziv='" + nazD + '\'' +
                ", opis='" + opisD + '\'' +
                ", datum='" + datD + '\'' +
                '}';
    }
}