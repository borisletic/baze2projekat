package rs.ac.uns.ftn.db.jdbc.alumniclub.dao;

import rs.ac.uns.ftn.db.jdbc.alumniclub.dto.AlumnusDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlumnusDAOImpl implements AlumnusDAO {
    private Connection connection;

    public AlumnusDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public List<AlumnusDTO> findAll() {
        List<AlumnusDTO> alumni = new ArrayList<>();
        String sql = """
            SELECT a.idAlumn, a.NazAlumn, a.idAlOd, ao.NazAlOd
            FROM ALUMNUS a
            LEFT JOIN ALUMNI_ODSEK ao ON a.idAlOd = ao.idAlOd
            ORDER BY a.NazAlumn
        """;

        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                AlumnusDTO alumnus = new AlumnusDTO(
                        rs.getInt("idAlumn"),
                        rs.getString("NazAlumn"),
                        rs.getInt("idAlOd"),
                        rs.getString("NazAlOd")
                );
                alumni.add(alumnus);
            }
        } catch (SQLException e) {
            System.err.println("Greška pri čitanju alumnista: " + e.getMessage());
        }

        return alumni;
    }

    @Override
    public AlumnusDTO findById(int id) {
        String sql = """
            SELECT a.idAlumn, a.NazAlumn, a.idAlOd, ao.NazAlOd
            FROM ALUMNUS a
            LEFT JOIN ALUMNI_ODSEK ao ON a.idAlOd = ao.idAlOd
            WHERE a.idAlumn = ?
        """;

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new AlumnusDTO(
                        rs.getInt("idAlumn"),
                        rs.getString("NazAlumn"),
                        rs.getInt("idAlOd"),
                        rs.getString("NazAlOd")
                );
            }
        } catch (SQLException e) {
            System.err.println("Greška pri čitanju alumnusa: " + e.getMessage());
        }

        return null;
    }

    @Override
    public boolean insert(AlumnusDTO alumnus) {
        String sql = "INSERT INTO ALUMNUS (idAlumn, NazAlumn, idAlOd) VALUES (?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, alumnus.getIdAlumn());
            ps.setString(2, alumnus.getNazAlumn());
            ps.setInt(3, alumnus.getIdAlOd());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Greška pri unosu alumnusa: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean update(AlumnusDTO alumnus) {
        String sql = "UPDATE ALUMNUS SET NazAlumn = ?, idAlOd = ? WHERE idAlumn = ?";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, alumnus.getNazAlumn());
            ps.setInt(2, alumnus.getIdAlOd());
            ps.setInt(3, alumnus.getIdAlumn());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Greška pri ažuriranju alumnusa: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM ALUMNUS WHERE idAlumn = ?";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Greška pri brisanju alumnusa: " + e.getMessage());
            return false;
        }
    }

    @Override
    public List<AlumnusDTO> findAlumniByDepartment(int departmentId) {
        List<AlumnusDTO> alumni = new ArrayList<>();
        String sql = """
            SELECT a.idAlumn, a.NazAlumn, a.idAlOd, ao.NazAlOd
            FROM ALUMNUS a
            JOIN ALUMNI_ODSEK ao ON a.idAlOd = ao.idAlOd
            WHERE a.idAlOd = ?
            ORDER BY a.NazAlumn
        """;

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, departmentId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                AlumnusDTO alumnus = new AlumnusDTO(
                        rs.getInt("idAlumn"),
                        rs.getString("NazAlumn"),
                        rs.getInt("idAlOd"),
                        rs.getString("NazAlOd")
                );
                alumni.add(alumnus);
            }
        } catch (SQLException e) {
            System.err.println("Greška pri čitanju alumnista po odseku: " + e.getMessage());
        }

        return alumni;
    }

    @Override
    public List<AlumnusDTO> findAlumniByEvent(int eventId) {
        List<AlumnusDTO> alumni = new ArrayList<>();
        String sql = """
            SELECT a.idAlumn, a.NazAlumn, a.idAlOd, ao.NazAlOd
            FROM ALUMNUS a
            JOIN UČESTVUJE u ON a.idAlumn = u.idAlumn
            LEFT JOIN ALUMNI_ODSEK ao ON a.idAlOd = ao.idAlOd
            WHERE u.idD = ?
            ORDER BY a.NazAlumn
        """;

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, eventId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                AlumnusDTO alumnus = new AlumnusDTO(
                        rs.getInt("idAlumn"),
                        rs.getString("NazAlumn"),
                        rs.getInt("idAlOd"),
                        rs.getString("NazAlOd")
                );
                alumni.add(alumnus);
            }
        } catch (SQLException e) {
            System.err.println("Greška pri čitanju alumnista po događaju: " + e.getMessage());
        }

        return alumni;
    }
}