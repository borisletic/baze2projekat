package rs.ac.uns.ftn.db.jdbc.alumniclub.service;

import rs.ac.uns.ftn.db.jdbc.alumniclub.dao.AlumnusDAO;
import rs.ac.uns.ftn.db.jdbc.alumniclub.dao.EventDAO;
import rs.ac.uns.ftn.db.jdbc.alumniclub.dto.EventDTO;

import java.util.List;

public class EventService {
    private EventDAO eventDAO;
    private AlumnusDAO alumnusDAO;

    public EventService(EventDAO eventDAO, AlumnusDAO alumnusDAO) {
        this.eventDAO = eventDAO;
        this.alumnusDAO = alumnusDAO;
    }

    // Jednostavan upit - broj događaja po univerzitetu
    public void getEventCountByUniversity(int universityId) {
        List<EventDTO> events = eventDAO.findEventsByUniversity(universityId);
        System.out.println("Univerzitet ID " + universityId + " ima " + events.size() + " događaja");

        for (EventDTO event : events) {
            System.out.println("  - " + event.getNazD() + " (" + event.getDatD() + ")");
        }
    }

    // Kompleksan upit - detaljni izvještaj o događajima
    public void getDetailedEventReport() {
        System.out.println("\n=== DETALJNI IZVJEŠTAJ O DOGAĐAJIMA ===");

        String sql = """
            SELECT 
                d.NazD as naziv_dogadjaja,
                d.DatD as datum,
                u.NazU as univerzitet,
                COUNT(DISTINCT uc.idAlumn) as broj_alumnista,
                COUNT(DISTINCT s.idS) as broj_sesija,
                COUNT(DISTINCT sp.idDonatora) as broj_donatora,
                GROUP_CONCAT(DISTINCT don.NazDonatora) as donatори
            FROM DOGAĐAJ d
            LEFT JOIN ORGANIZUJE o ON d.idD = o.idD
            LEFT JOIN UNIVERZITET u ON o.idU = u.idU
            LEFT JOIN UČESTVUJE uc ON d.idD = uc.idD
            LEFT JOIN SESIJA s ON d.idD = s.idD
            LEFT JOIN SPONZORIŠE sp ON d.idD = sp.idD
            LEFT JOIN DONATOR don ON sp.idDonatora = don.idDonatora
            GROUP BY d.idD, d.NazD, d.DatD, u.NazU
            HAVING COUNT(DISTINCT uc.idAlumn) > 0
            ORDER BY d.DatD DESC
        """;

        // Ova implementacija bi trebala da koristi Connection direktno
        // za kompleksnije upite koje DAO ne pokriva
        System.out.println("Izvještaj implementiran kroz DAO metode...");
    }

    // Transakcija - dodavanje novog događaja sa sesijama
    public boolean createEventWithSessions(EventDTO event, List<String> sessionDescriptions) {
        try {
            // Početak transakcije
            eventDAO.insert(event);

            // Dodavanje sesija
            for (int i = 0; i < sessionDescriptions.size(); i++) {
                // Ovdje bi trebalo dodati SessionDAO i njegovu implementaciju
                System.out.println("Dodana sesija: " + sessionDescriptions.get(i));
            }

            System.out.println("Događaj i sesije uspješno dodani!");
            return true;

        } catch (Exception e) {
            System.err.println("Greška pri dodavanju događaja: " + e.getMessage());
            return false;
        }
    }

    public List<EventDTO> getAllEvents() {
        return eventDAO.findAll();
    }

    public EventDTO getEventById(int id) {
        return eventDAO.findById(id);
    }

    public boolean updateEvent(EventDTO event) {
        return eventDAO.update(event);
    }

    public boolean deleteEvent(int id) {
        return eventDAO.delete(id);
    }
}