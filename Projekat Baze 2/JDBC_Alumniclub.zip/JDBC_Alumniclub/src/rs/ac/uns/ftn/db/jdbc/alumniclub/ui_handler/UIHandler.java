package rs.ac.uns.ftn.db.jdbc.alumniclub.ui_handler;

import rs.ac.uns.ftn.db.jdbc.alumniclub.dto.EventDTO;
import rs.ac.uns.ftn.db.jdbc.alumniclub.dto.AlumnusDTO;
import rs.ac.uns.ftn.db.jdbc.alumniclub.service.AlumnusService;
import rs.ac.uns.ftn.db.jdbc.alumniclub.service.EventService;

import java.util.List;
import java.util.Scanner;

public class UIHandler {
    private EventService eventService;
    private AlumnusService alumnusService;
    private Scanner scanner;

    public UIHandler(EventService eventService, AlumnusService alumnusService) {
        this.eventService = eventService;
        this.alumnusService = alumnusService;
        this.scanner = new Scanner(System.in);
    }

    public void showMainMenu() {
        while (true) {
            System.out.println("\n=== UNIVERZITETSKO UDRUŽENJE ALUMNISTA ===");
            System.out.println("1. Upravljanje događajima");
            System.out.println("2. Upravljanje alumnistima");
            System.out.println("3. Izvještaji");
            System.out.println("4. Izlaz");
            System.out.print("Izaberite opciju: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    handleEventMenu();
                    break;
                case 2:
                    handleAlumnusMenu();
                    break;
                case 3:
                    handleReportsMenu();
                    break;
                case 4:
                    System.out.println("Doviđenja!");
                    return;
                default:
                    System.out.println("Neispravna opcija!");
            }
        }
    }

    private void handleEventMenu() {
        System.out.println("\n=== UPRAVLJANJE DOGAĐAJIMA ===");
        System.out.println("1. Prikaži sve događaje");
        System.out.println("2. Dodaj novi događaj");
        System.out.println("3. Ažuriraj događaj");
        System.out.println("4. Obriši događaj");
        System.out.println("5. Nazad");
        System.out.print("Izaberite opciju: ");

        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                showAllEvents();
                break;
            case 2:
                addNewEvent();
                break;
            case 3:
                updateEvent();
                break;
            case 4:
                deleteEvent();
                break;
            case 5:
                return;
            default:
                System.out.println("Neispravna opcija!");
        }
    }

    private void handleAlumnusMenu() {
        System.out.println("\n=== UPRAVLJANJE ALUMNISTIMA ===");
        System.out.println("1. Prikaži sve alumniste");
        System.out.println("2. Dodaj novog alumnusa");
        System.out.println("3. Ažuriraj alumnusa");
        System.out.println("4. Obriši alumnusa");
        System.out.println("5. Prikaži alumniste po odseku");
        System.out.println("6. Nazad");
        System.out.print("Izaberite opciju: ");

        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                showAllAlumni();
                break;
            case 2:
                addNewAlumnus();
                break;
            case 3:
                updateAlumnus();
                break;
            case 4:
                deleteAlumnus();
                break;
            case 5:
                showAlumniByDepartment();
                break;
            case 6:
                return;
            default:
                System.out.println("Neispravna opcija!");
        }
    }

    private void handleReportsMenu() {
        System.out.println("\n=== IZVJEŠTAJI ===");
        System.out.println("1. Događaji po univerzitetu");
        System.out.println("2. Detaljni izvještaj o događajima");
        System.out.println("3. Alumnisti po događaju");
        System.out.println("4. Nazad");
        System.out.print("Izaberite opciju: ");

        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                showEventsByUniversity();
                break;
            case 2:
                eventService.getDetailedEventReport();
                break;
            case 3:
                showAlumniByEvent();
                break;
            case 4:
                return;
            default:
                System.out.println("Neispravna opcija!");
        }
    }

    private void showAllEvents() {
        List<EventDTO> events = eventService.getAllEvents();
        System.out.println("\n=== SVI DOGAĐAJI ===");
        for (EventDTO event : events) {
            System.out.println(event);
        }
    }

    private void addNewEvent() {
        System.out.println("\n=== DODAVANJE NOVOG DOGAĐAJA ===");
        System.out.print("ID događaja: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Naziv događaja: ");
        String naziv = scanner.nextLine();

        System.out.print("Opis događaja: ");
        String opis = scanner.nextLine();

        System.out.print("Datum događaja (YYYY-MM-DD): ");
        String datum = scanner.nextLine();

        EventDTO event = new EventDTO(id, naziv, opis, datum);

        if (eventService.createEventWithSessions(event, List.of("Glavna sesija"))) {
            System.out.println("Događaj uspješno dodan!");
        } else {
            System.out.println("Greška pri dodavanju događaja!");
        }
    }

    private void updateEvent() {
        System.out.print("Unesite ID događaja za ažuriranje: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        EventDTO event = eventService.getEventById(id);
        if (event == null) {
            System.out.println("Događaj nije pronađen!");
            return;
        }

        System.out.println("Trenutni podaci: " + event);
        System.out.print("Novi naziv (ostavite prazno za zadržavanje): ");
        String naziv = scanner.nextLine();
        if (!naziv.isEmpty()) {
            event.setNazD(naziv);
        }

        System.out.print("Novi opis (ostavite prazno za zadržavanje): ");
        String opis = scanner.nextLine();
        if (!opis.isEmpty()) {
            event.setOpisD(opis);
        }

        System.out.print("Novi datum (ostavite prazno za zadržavanje): ");
        String datum = scanner.nextLine();
        if (!datum.isEmpty()) {
            event.setDatD(datum);
        }

        if (eventService.updateEvent(event)) {
            System.out.println("Događaj uspješno ažuriran!");
        } else {
            System.out.println("Greška pri ažuriranju događaja!");
        }
    }

    private void deleteEvent() {
        System.out.print("Unesite ID događaja za brisanje: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        if (eventService.deleteEvent(id)) {
            System.out.println("Događaj uspješno obrisan!");
        } else {
            System.out.println("Greška pri brisanju događaja!");
        }
    }

    private void showAllAlumni() {
        List<AlumnusDTO> alumni = alumnusService.getAllAlumni();
        System.out.println("\n=== SVI ALUMNISTI ===");
        for (AlumnusDTO alumnus : alumni) {
            System.out.println(alumnus);
        }
    }

    private void addNewAlumnus() {
        System.out.println("\n=== DODAVANJE NOVOG ALUMNUSA ===");
        System.out.print("ID alumnusa: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Naziv alumnusa: ");
        String naziv = scanner.nextLine();

        System.out.print("ID odseka: ");
        int odsetId = scanner.nextInt();
        scanner.nextLine();

        AlumnusDTO alumnus = new AlumnusDTO(id, naziv, odsetId, "");

        if (alumnusService.createAlumnus(alumnus)) {
            System.out.println("Alumnus uspješno dodan!");
        } else {
            System.out.println("Greška pri dodavanju alumnusa!");
        }
    }

    private void updateAlumnus() {
        System.out.print("Unesite ID alumnusa za ažuriranje: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        AlumnusDTO alumnus = alumnusService.getAlumnusById(id);
        if (alumnus == null) {
            System.out.println("Alumnus nije pronađen!");
            return;
        }

        System.out.println("Trenutni podaci: " + alumnus);
        System.out.print("Novi naziv (ostavite prazno za zadržavanje): ");
        String naziv = scanner.nextLine();
        if (!naziv.isEmpty()) {
            alumnus.setNazAlumn(naziv);
        }

        System.out.print("Novi ID odseka (0 za zadržavanje): ");
        int odsetId = scanner.nextInt();
        scanner.nextLine();
        if (odsetId != 0) {
            alumnus.setIdAlOd(odsetId);
        }

        if (alumnusService.updateAlumnus(alumnus)) {
            System.out.println("Alumnus uspješno ažuriran!");
        } else {
            System.out.println("Greška pri ažuriranju alumnusa!");
        }
    }

    private void deleteAlumnus() {
        System.out.print("Unesite ID alumnusa za brisanje: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        if (alumnusService.deleteAlumnus(id)) {
            System.out.println("Alumnus uspješno obrisan!");
        } else {
            System.out.println("Greška pri brisanju alumnusa!");
        }
    }

    private void showAlumniByDepartment() {
        System.out.print("Unesite ID odseka: ");
        int departmentId = scanner.nextInt();
        scanner.nextLine();

        List<AlumnusDTO> alumni = alumnusService.getAlumniByDepartment(departmentId);
        System.out.println("\n=== ALUMNISTI ODSEKA " + departmentId + " ===");
        for (AlumnusDTO alumnus : alumni) {
            System.out.println(alumnus);
        }
    }

    private void showEventsByUniversity() {
        System.out.print("Unesite ID univerziteta: ");
        int universityId = scanner.nextInt();
        scanner.nextLine();

        eventService.getEventCountByUniversity(universityId);
    }

    private void showAlumniByEvent() {
        System.out.print("Unesite ID događaja: ");
        int eventId = scanner.nextInt();
        scanner.nextLine();

        List<AlumnusDTO> alumni = alumnusService.getAlumniByEvent(eventId);
        System.out.println("\n=== ALUMNISTI NA DOGAĐAJU " + eventId + " ===");
        for (AlumnusDTO alumnus : alumni) {
            System.out.println(alumnus);
        }
    }
}