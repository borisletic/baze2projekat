package rs.ac.uns.ftn.db.jdbc.alumniclub.dao;

import rs.ac.uns.ftn.db.jdbc.alumniclub.connection.DatabaseConnection;
import java.sql.*;
import java.util.*;

public class ReportDAOImpl implements ReportDAO {
    private Connection connection;

    // Fixed no-arg constructor - gets connection from DatabaseConnection
    public ReportDAOImpl() {
        try {
            this.connection = DatabaseConnection.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to establish database connection", e);
        }
    }

    // Add constructor that accepts connection for flexibility
    public ReportDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public List<Map<String, Object>> getAlumniCountByDepartment() {
        List<Map<String, Object>> results = new ArrayList<>();
        String sql = """
            SELECT 
                ao.NazAlOd as naziv_odseka,
                COUNT(a.idAlumn) as broj_alumnista,
                COALESCE(AVG(a.idAlumn), 0) as prosecni_id
            FROM ALUMNI_ODSEK ao
            LEFT JOIN ALUMNUS a ON ao.idAlOd = a.idAlOd
            GROUP BY ao.idAlOd, ao.NazAlOd
            ORDER BY COUNT(a.idAlumn) DESC
        """;

        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("naziv_odseka", rs.getString("naziv_odseka"));
                row.put("broj_alumnista", rs.getInt("broj_alumnista"));
                row.put("prosecni_id", rs.getDouble("prosecni_id"));
                results.add(row);
            }
        } catch (SQLException e) {
            System.err.println("Greška pri izvršavanju upita: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    @Override
    public List<Map<String, Object>> getDetailedEventReport() {
        List<Map<String, Object>> results = new ArrayList<>();
        String sql = """
            SELECT 
                d.NazD as naziv_dogadjaja,
                d.DatD as datum_dogadjaja,
                u.NazU as organizator_univerzitet,
                COUNT(DISTINCT uc.idAlumn) as broj_ucesnika,
                COUNT(DISTINCT s.idS) as broj_sesija,
                COUNT(DISTINCT sp.idDonatora) as broj_donatora,
                COUNT(DISTINCT p.idP) as broj_priznanja,
                CASE 
                    WHEN COUNT(DISTINCT uc.idAlumn) >= 5 THEN 'Veliki događaj'
                    WHEN COUNT(DISTINCT uc.idAlumn) >= 2 THEN 'Srednji događaj'
                    ELSE 'Mali događaj'
                END as kategorija_dogadjaja
            FROM DOGAĐAJ d
            LEFT OUTER JOIN ORGANIZUJE o ON d.idD = o.idD
            LEFT OUTER JOIN UNIVERZITET u ON o.idU = u.idU
            LEFT OUTER JOIN UČESTVUJE uc ON d.idD = uc.idD
            LEFT OUTER JOIN SESIJA s ON d.idD = s.idD
            LEFT OUTER JOIN SPONZORIŠE sp ON d.idD = sp.idD
            LEFT OUTER JOIN PRIZNANJE p ON d.idD = p.idD
            WHERE d.DatD >= '2024-01-01'
            GROUP BY d.idD, d.NazD, d.DatD, u.NazU
            ORDER BY d.DatD DESC
        """;

        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("naziv_dogadjaja", rs.getString("naziv_dogadjaja"));
                row.put("datum_dogadjaja", rs.getDate("datum_dogadjaja"));
                row.put("organizator_univerzitet", rs.getString("organizator_univerzitet"));
                row.put("broj_ucesnika", rs.getInt("broj_ucesnika"));
                row.put("broj_sesija", rs.getInt("broj_sesija"));
                row.put("broj_donatora", rs.getInt("broj_donatora"));
                row.put("broj_priznanja", rs.getInt("broj_priznanja"));
                row.put("kategorija_dogadjaja", rs.getString("kategorija_dogadjaja"));
                results.add(row);
            }
        } catch (SQLException e) {
            System.err.println("Greška pri detaljnom izvještaju: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    @Override
    public List<Map<String, Object>> getActivityAnalysisByLocation() {
        List<Map<String, Object>> results = new ArrayList<>();
        String sql = """
            SELECT 
                g.NazG as grad,
                l.NazL as lokacija,
                COUNT(DISTINCT a.rbrA, a.idS) as broj_aktivnosti,
                COUNT(DISTINCT s.idS) as broj_sesija,
                COUNT(DISTINCT d.idD) as broj_dogadjaja,
                COUNT(DISTINCT k.idK) as broj_koordinatora,
                MIN(d.DatD) as prvi_dogadjaj,
                MAX(d.DatD) as poslednji_dogadjaj
            FROM LOKACIJA l
            LEFT JOIN NALAZI_SE ns ON l.idL = ns.idL
            LEFT JOIN GRAD g ON ns.idG = g.idG
            LEFT JOIN AKTIVNOST a ON l.idL = a.idL
            LEFT JOIN SESIJA s ON a.idS = s.idS
            LEFT JOIN DOGAĐAJ d ON s.idD = d.idD
            LEFT JOIN KOORDINIRA ko ON a.rbrA = ko.rbrA AND a.idS = ko.idS
            LEFT JOIN KOORDINATOR k ON ko.idK = k.idK
            GROUP BY l.idL, l.NazL, g.idG, g.NazG
            HAVING COUNT(DISTINCT a.rbrA, a.idS) > 0
            ORDER BY broj_aktivnosti DESC
        """;

        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("grad", rs.getString("grad"));
                row.put("lokacija", rs.getString("lokacija"));
                row.put("broj_aktivnosti", rs.getInt("broj_aktivnosti"));
                row.put("broj_sesija", rs.getInt("broj_sesija"));
                row.put("broj_dogadjaja", rs.getInt("broj_dogadjaja"));
                row.put("broj_koordinatora", rs.getInt("broj_koordinatora"));
                row.put("prvi_dogadjaj", rs.getDate("prvi_dogadjaj"));
                row.put("poslednji_dogadjaj", rs.getDate("poslednji_dogadjaj"));
                results.add(row);
            }
        } catch (SQLException e) {
            System.err.println("Greška pri analizi aktivnosti po lokacijama: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    @Override
    public List<Map<String, Object>> getCoordinatorHierarchyAnalysis() {
        List<Map<String, Object>> results = new ArrayList<>();
        String sql = """
            SELECT 
                koo.NazK as koordinator,
                nad.NazK as nadredjeni_koordinator,
                (SELECT COUNT(*) FROM KOORDINATOR pod WHERE pod.idK_nadređeni = koo.idK) as broj_podredjenih,
                COUNT(DISTINCT k.rbrA, k.idS) as broj_aktivnosti,
                CASE 
                    WHEN koo.idK_nadređeni IS NULL THEN 'Glavni koordinator'
                    WHEN (SELECT COUNT(*) FROM KOORDINATOR pod WHERE pod.idK_nadređeni = koo.idK) > 0 THEN 'Srednji menadžer'
                    ELSE 'Izvršni koordinator'
                END as tip_koordinatora
            FROM KOORDINATOR koo
            LEFT JOIN KOORDINATOR nad ON koo.idK_nadređeni = nad.idK
            LEFT JOIN KOORDINIRA k ON koo.idK = k.idK
            GROUP BY koo.idK, koo.NazK, nad.NazK, koo.idK_nadređeni
            ORDER BY CASE WHEN koo.idK_nadređeni IS NULL THEN 0 ELSE 1 END, koo.idK_nadređeni, koo.NazK
        """;

        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("koordinator", rs.getString("koordinator"));
                row.put("nadredjeni_koordinator", rs.getString("nadredjeni_koordinator"));
                row.put("broj_podredjenih", rs.getInt("broj_podredjenih"));
                row.put("broj_aktivnosti", rs.getInt("broj_aktivnosti"));
                row.put("tip_koordinatora", rs.getString("tip_koordinatora"));
                results.add(row);
            }
        } catch (SQLException e) {
            System.err.println("Greška pri hijerarhijskoj analizi: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    @Override
    public List<Map<String, Object>> getMostActiveAlumniReport() {
        List<Map<String, Object>> results = new ArrayList<>();
        String sql = """
            SELECT 
                a.NazAlumn as alumnus,
                ao.NazAlOd as odsek,
                COUNT(DISTINCT u.idD) as broj_dogadjaja,
                COUNT(DISTINCT dp.idP) as broj_priznanja,
                CASE 
                    WHEN COUNT(DISTINCT u.idD) >= 5 THEN 'Veoma aktivan'
                    WHEN COUNT(DISTINCT u.idD) >= 3 THEN 'Aktivan'
                    ELSE 'Malo aktivan'
                END as nivo_aktivnosti
            FROM ALUMNUS a
            JOIN ALUMNI_ODSEK ao ON a.idAlOd = ao.idAlOd
            LEFT JOIN UČESTVUJE u ON a.idAlumn = u.idAlumn
            LEFT JOIN DOBIJA_PRIZNANJE dp ON a.idAlumn = dp.idAlumn
            LEFT JOIN PRIZNANJE p ON dp.idP = p.idP
            GROUP BY a.idAlumn, a.NazAlumn, ao.NazAlOd
            HAVING COUNT(DISTINCT u.idD) > 0
            ORDER BY broj_dogadjaja DESC, broj_priznanja DESC
            LIMIT 20
        """;

        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("alumnus", rs.getString("alumnus"));
                row.put("odsek", rs.getString("odsek"));
                row.put("broj_dogadjaja", rs.getInt("broj_dogadjaja"));
                row.put("broj_priznanja", rs.getInt("broj_priznanja"));
                row.put("nivo_aktivnosti", rs.getString("nivo_aktivnosti"));
                results.add(row);
            }
        } catch (SQLException e) {
            System.err.println("Greška pri izvještaju najaktivnijih alumnista: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    @Override
    public List<Map<String, Object>> getDonorEfficiencyReport() {
        List<Map<String, Object>> results = new ArrayList<>();
        String sql = """
            SELECT 
                d.NazDonatora as donator,
                COUNT(DISTINCT s.idD) as broj_sponzorisanih_dogadjaja,
                COUNT(DISTINCT u.idAlumn) as ukupno_dostignuto_alumnista,
                ROUND(COUNT(DISTINCT u.idAlumn) * 1.0 / COUNT(DISTINCT s.idD), 2) as prosecno_alumnista_po_dogadjaju
            FROM DONATOR d
            JOIN SPONZORIŠE s ON d.idDonatora = s.idDonatora
            LEFT JOIN UČESTVUJE u ON s.idD = u.idD
            GROUP BY d.idDonatora, d.NazDonatora
            HAVING COUNT(DISTINCT s.idD) > 0
            ORDER BY ukupno_dostignuto_alumnista DESC
        """;

        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("donator", rs.getString("donator"));
                row.put("broj_sponzorisanih_dogadjaja", rs.getInt("broj_sponzorisanih_dogadjaja"));
                row.put("ukupno_dostignuto_alumnista", rs.getInt("ukupno_dostignuto_alumnista"));
                row.put("prosecno_alumnista_po_dogadjaju", rs.getDouble("prosecno_alumnista_po_dogadjaju"));
                results.add(row);
            }
        } catch (SQLException e) {
            System.err.println("Greška pri izvještaju efikasnosti donatora: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    @Override
    public List<Map<String, Object>> getMonthlyActivityReport() {
        List<Map<String, Object>> results = new ArrayList<>();
        String sql = """
            SELECT 
                YEAR(d.DatD) as godina,
                MONTH(d.DatD) as mesec,
                MONTHNAME(d.DatD) as naziv_meseca,
                COUNT(DISTINCT d.idD) as broj_dogadjaja,
                COUNT(DISTINCT u.idAlumn) as broj_ucesnika,
                COUNT(DISTINCT s.idS) as broj_sesija
            FROM DOGAĐAJ d
            LEFT JOIN UČESTVUJE u ON d.idD = u.idD
            LEFT JOIN SESIJA s ON d.idD = s.idD
            WHERE d.DatD >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
            GROUP BY YEAR(d.DatD), MONTH(d.DatD), MONTHNAME(d.DatD)
            ORDER BY godina DESC, mesec DESC
        """;

        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("godina", rs.getInt("godina"));
                row.put("mesec", rs.getInt("mesec"));
                row.put("naziv_meseca", rs.getString("naziv_meseca"));
                row.put("broj_dogadjaja", rs.getInt("broj_dogadjaja"));
                row.put("broj_ucesnika", rs.getInt("broj_ucesnika"));
                row.put("broj_sesija", rs.getInt("broj_sesija"));
                results.add(row);
            }
        } catch (SQLException e) {
            System.err.println("Greška pri mesečnom izvještaju: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    // Clean up method
    public void close() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.err.println("Greška pri zatvaranju konekcije: " + e.getMessage());
            }
        }
    }
}