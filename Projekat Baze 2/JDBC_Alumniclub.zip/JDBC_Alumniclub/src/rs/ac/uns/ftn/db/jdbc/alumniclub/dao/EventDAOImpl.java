package rs.ac.uns.ftn.db.jdbc.alumniclub.dao;

import rs.ac.uns.ftn.db.jdbc.alumniclub.dto.EventDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EventDAOImpl implements EventDAO {
    private Connection connection;

    public EventDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public List<EventDTO> findAll() {
        List<EventDTO> events = new ArrayList<>();
        String sql = "SELECT * FROM DOGAĐAJ ORDER BY DatD DESC";

        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                EventDTO event = new EventDTO(
                        rs.getInt("idD"),
                        rs.getString("NazD"),
                        rs.getString("OpisD"),
                        rs.getString("DatD")
                );
                events.add(event);
            }
        } catch (SQLException e) {
            System.err.println("Greška pri čitanju događaja: " + e.getMessage());
        }

        return events;
    }

    @Override
    public EventDTO findById(int id) {
        String sql = "SELECT * FROM DOGAĐAJ WHERE idD = ?";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new EventDTO(
                        rs.getInt("idD"),
                        rs.getString("NazD"),
                        rs.getString("OpisD"),
                        rs.getString("DatD")
                );
            }
        } catch (SQLException e) {
            System.err.println("Greška pri čitanju događaja: " + e.getMessage());
        }

        return null;
    }

    @Override
    public boolean insert(EventDTO event) {
        String sql = "INSERT INTO DOGAĐAJ (idD, NazD, OpisD, DatD) VALUES (?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, event.getIdD());
            ps.setString(2, event.getNazD());
            ps.setString(3, event.getOpisD());
            ps.setString(4, event.getDatD());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Greška pri unosu događaja: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean update(EventDTO event) {
        String sql = "UPDATE DOGAĐAJ SET NazD = ?, OpisD = ?, DatD = ? WHERE idD = ?";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, event.getNazD());
            ps.setString(2, event.getOpisD());
            ps.setString(3, event.getDatD());
            ps.setInt(4, event.getIdD());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Greška pri ažuriranju događaja: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM DOGAĐAJ WHERE idD = ?";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Greška pri brisanju događaja: " + e.getMessage());
            return false;
        }
    }

    @Override
    public List<EventDTO> findEventsByUniversity(int universityId) {
        List<EventDTO> events = new ArrayList<>();
        String sql = """
            SELECT d.idD, d.NazD, d.OpisD, d.DatD
            FROM DOGAĐAJ d
            JOIN ORGANIZUJE o ON d.idD = o.idD
            WHERE o.idU = ?
            ORDER BY d.DatD DESC
        """;

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, universityId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                EventDTO event = new EventDTO(
                        rs.getInt("idD"),
                        rs.getString("NazD"),
                        rs.getString("OpisD"),
                        rs.getString("DatD")
                );
                events.add(event);
            }
        } catch (SQLException e) {
            System.err.println("Greška pri čitanju događaja po univerzitetu: " + e.getMessage());
        }

        return events;
    }

    @Override
    public List<EventDTO> findUpcomingEvents() {
        List<EventDTO> events = new ArrayList<>();
        String sql = "SELECT * FROM DOGAĐAJ WHERE DatD >= CURRENT_DATE ORDER BY DatD";

        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                EventDTO event = new EventDTO(
                        rs.getInt("idD"),
                        rs.getString("NazD"),
                        rs.getString("OpisD"),
                        rs.getString("DatD")
                );
                events.add(event);
            }
        } catch (SQLException e) {
            System.err.println("Greška pri čitanju budućih događaja: " + e.getMessage());
        }

        return events;
    }
}